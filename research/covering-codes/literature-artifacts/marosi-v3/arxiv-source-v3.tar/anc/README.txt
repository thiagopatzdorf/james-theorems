Ancillary files for "New upper and lower bounds on covering codes K_q(n,R)
for alphabets of size 5 <= q <= 21" (arXiv:2608.19872, version 3).

Contents: 26 code files (Table 1), 58 certificate files (Table 2), and the
three checkers verify_cov.py, verify_independent.py and certify.py.

K{q}_{n}_{R}_M{M}.txt   -- code of size M in Z_q^n with covering radius <= R,
                           one codeword per line, digits 0-9 then a-z for
                           q > 10.
  Check:    python3 verify_cov.py -q 6 -n 8 -R 4 K6_8_4_M166.txt
            (Python standard library; numpy is used if present)
  A second checker sharing no code with the first is included:
            python3 verify_independent.py K6_8_4_M166.txt -q 6 -n 8 -R 4
            (dilation of the indicator array, and a minimum-distance scan
            that reports the exact covering radius; requires numpy).
  Resource needs of the largest codes with verify_independent.py --method
  dilate (measured, CPU only):
    K_9(10,5)  (q^n = 3.5e9): about 3.5 GB of memory, about 5 minutes
    K_10(10,5) (q^n = 1e10):  about 10 GB of memory, about 20 minutes
  All other codes are checked in seconds. Above q^n ~ 1e9 use the dilation
  method; verify_cov.py --method numpy also completes but needs more memory
  at the largest sizes.

cert_q{q}_n{n}_R{R}.json -- exact rational dual solution of the semidefinite
                            program of Appendix B, proving the lower bound
                            of Table 2 for that cell.
  Check:    python3 certify.py cert_q6_n10_R4.json
            (Python standard library only; rebuilds the program from
            (q,n,R) and checks the certificate in exact arithmetic)
  In each file, claim.sdp_bound_num / claim.sdp_bound_den is the exact
  rational value certified for the program, which bounds the CUBE of the
  covering number: K_lower_bound = ceil((sdp_bound_num/sdp_bound_den)^(1/3)).
  Example: q=12, n=8, R=2: cube root = 125155.98..., so K_12(8,2) >= 125156.

Only certificates that improve the tabulated lower bound are included. A
certificate proves a lower bound on the optimum of the relaxation; a
certificate whose value does not exceed the tabulated bound is not an
improvement, and one whose value lies below the sphere-covering bound
ceil(q^n/|B_R|) (which happens when the numerical solver does not converge)
carries no information. Of the 196 certificate files produced in this work,
58 improve the tabulated bound (included here), 28 attain it exactly, 82 lie
between the sphere-covering bound and the tabulated bound, and 28 lie below
the sphere-covering bound; the 138 non-improving files are kept in the
source repository (cov/lb/certs_all) and are not part of this package.
